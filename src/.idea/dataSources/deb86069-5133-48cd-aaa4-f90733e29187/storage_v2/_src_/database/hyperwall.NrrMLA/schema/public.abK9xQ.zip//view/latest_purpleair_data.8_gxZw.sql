create view latest_purpleair_data
            (purpleair_id, time, pm2_5, temperature, humidity, corrected_pm2_5, correction_method, latitude, longitude,
             end_time, server_time)
as
SELECT h.purpleair_id,
       h."time",
       h.pm2_5,
       h.temperature,
       h.humidity,
       h.corrected_pm2_5,
       h.correction_method,
       h.latitude,
       h.longitude,
       h.end_time,
       h.server_time
FROM purpleair_history h
         JOIN (SELECT purpleair_history.purpleair_id,
                      max(purpleair_history."time") AS "time"
               FROM purpleair_history
               GROUP BY purpleair_history.purpleair_id) m ON h.purpleair_id = m.purpleair_id AND h."time" = m."time"
ORDER BY h.purpleair_id;

alter table latest_purpleair_data
    owner to postgres;

